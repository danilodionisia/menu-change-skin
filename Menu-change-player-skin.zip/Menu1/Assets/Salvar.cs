﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using System.IO;

public class Salvar : MonoBehaviour {

    public void salvar()
    {
        StreamReader leitor = new StreamReader(@"C:\Users\danilo.dionisia\Documents\settings.txt");
        string texto ="";

        while(leitor.ReadLine() != null)
        {
            texto += leitor.ReadLine();
        }
        leitor.Close();

        StreamWriter w = new StreamWriter(@"C:\Users\danilo.dionisia\Documents\settings.txt");
        texto = "Nome: Danilo/Pontos: " + Player.pts.ToString();
        w.WriteLine(texto);
        w.Close();

    }

    // Use this for initialization
    void Start () {
        StreamWriter escreve = new StreamWriter(@"C:\Users\danilo.dionisia\Documents\settings.txt");
        escreve.WriteLine();
        escreve.Close();

    }
	
	// Update is called once per frame
	void Update () {
		
        
	}
}
