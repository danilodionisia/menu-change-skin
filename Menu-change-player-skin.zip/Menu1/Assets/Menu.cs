﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.IO;

public class Menu : MonoBehaviour {

    public void loadScenes(int c)
    {
        SceneManager.LoadScene(c);
    }
	
	void Start () {
		
	}
	
	
	void Update () {
		
	}
}
