﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Settings : MonoBehaviour {

    public Scrollbar sb;
    public AudioSource audioJogo;
    public GameObject go;
    public Sprite sp1, sp2, sp3;
    public int skin;

	void Start () {
        skin = 1;
	}
	
	// Update is called once per frame
	void Update () {
        float v = sb.value;
        audioJogo.volume = v;
        print(v.ToString());

        switch (skin)
        {
            case 1:
                go.GetComponent<SpriteRenderer>().sprite = sp1;
                break;

            case 2:
                go.GetComponent<SpriteRenderer>().sprite = sp2;
                break;

            case 3:
                go.GetComponent<SpriteRenderer>().sprite = sp3;
                break;
        }
        
    }

    public void skinRight()
    {
        if (skin < 3)
        {
            skin++;
        }
    }

    public void skinLeft()
    {
        if (skin > 1)
        {
            skin--;
        }
    }

    public void playAudio()
    {
        audioJogo.Play();
    }

    public void pauseAudio()
    {
        audioJogo.Pause();
    }

    public void stopAudio()
    {
        audioJogo.Stop();
    }
}
