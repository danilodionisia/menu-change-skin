﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Player : MonoBehaviour {
    public static int pts;
    public float vel;
    public Text placar;

	void Start () {
        vel = 0.05f;
        pts = 0;
	}
		
	void Update () {
        placar.text = "Pontos: " + pts.ToString();

	    if(Input.GetAxis("Horizontal") > 0)
        {
            transform.Translate(Vector3.right * vel);
            transform.localScale = new Vector2(-1.6f,1.7f);
        }
        if (Input.GetAxis("Horizontal") < 0)
        {
            transform.Translate(Vector3.left * vel);
            transform.localScale = new Vector2(1.6f,1.7f);
        }

        if (Input.GetAxis("Vertical") > 0)
        {
            transform.Translate(Vector3.up * (vel + 0.08f));
        }

        if (Input.GetKey(KeyCode.Escape))
        {
            SceneManager.LoadScene(2);
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.tag == "coin")
        {
            pts += 1;
            Destroy(collision.gameObject);
        }
    }

}
